function HomePage() {
  return (
    <div className="container">
      <h1>Beranda</h1>
      <p>Ini halaman beranda lho</p>
    </div>
  )
}

export default HomePage
